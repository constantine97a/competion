1.编程语言为Python3.6 
2.依赖库：urllib，BeautifulSoup，keras，numpy，matplotlib，seaborn，pandas
3.工作环境：Anaconda
4.编译器：Jupyter notebook